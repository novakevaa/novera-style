import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Dimensions,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

const palette = {
  light: {
    background: '#FFF9F5',
    surface: '#FFFFFF',
    surfaceAlt: '#FFF1EA',
    text: '#211B19',
    muted: '#786E69',
    border: '#EBDDD5',
    gold: '#B88A43',
    peach: '#F1B9A5',
    blush: '#F8D8D6',
    shadow: '#8E6C5F',
    overlay: 'rgba(33, 27, 25, 0.34)',
  },
  dark: {
    background: '#0F0F10',
    surface: '#18181A',
    surfaceAlt: '#232124',
    text: '#F7F2EA',
    muted: '#B7AEA6',
    border: '#363238',
    gold: '#D5B06B',
    peach: '#8A5C51',
    blush: '#3A292D',
    shadow: '#000000',
    overlay: 'rgba(0, 0, 0, 0.48)',
  },
};

const copy = {
  ru: {
    continue: 'Продолжить',
    back: 'Назад',
    skip: 'Пропустить',
    welcomeEyebrow: 'ВАШ ПЕРСОНАЛЬНЫЙ СТИЛИСТ',
    welcomeTitle: 'Образы, которые выглядят как вы.',
    welcomeText: 'NOVERA собирает полный образ под ваш город, событие, бюджет и личный стиль.',
    start: 'Начать',
    languageTitle: 'Выберите язык',
    languageText: 'Язык можно изменить позже в настройках.',
    authTitle: 'Добро пожаловать в NOVERA',
    signup: 'Регистрация',
    login: 'Войти',
    name: 'Имя',
    email: 'Email',
    password: 'Пароль',
    authHint: 'Демо-версия: данные сохраняются только на устройстве.',
    genderTitle: 'Для кого подбираем образы?',
    genderText: 'Это влияет на подбор вещей, но не ограничивает ваш стиль.',
    women: 'Женщины',
    men: 'Мужчины',
    unisex: 'Унисекс',
    cityTitle: 'Где вы находитесь?',
    cityText: 'Мы покажем вещи, доступные в вашем городе и с подходящей доставкой.',
    cityPlaceholder: 'Введите город',
    appearanceTitle: 'Выберите оформление',
    appearanceText: 'Тему всегда можно поменять в профиле.',
    lightTheme: 'Светлая тема',
    darkTheme: 'Тёмная тема',
    occasionTitle: 'Куда вы собираетесь?',
    occasionText: 'Выберите повод — стилист учтёт дресс-код и настроение.',
    date: 'Свидание',
    party: 'Вечеринка',
    birthday: 'День рождения',
    restaurant: 'Ресторан',
    concert: 'Концерт',
    wedding: 'Свадьба',
    work: 'Работа',
    travel: 'Путешествие',
    other: 'Другое',
    measurementsTitle: 'Ваши параметры',
    measurementsText: 'Так рекомендации будут реалистичными и сразу подойдут по размеру.',
    budget: 'Бюджет на образ',
    clothingSize: 'Размер одежды',
    shoeSize: 'Размер обуви',
    height: 'Рост, см',
    prefsTitle: 'Ваши предпочтения',
    prefsText: 'Выберите любимые оттенки и напишите, что точно не носите.',
    favoriteColors: 'Любимые цвета',
    avoid: 'Не ношу / не люблю',
    avoidPlaceholder: 'Например: мини, каблуки, неон, кожа…',
    uploadTitle: 'Добавьте референсы',
    uploadText: 'Загрузите свои фото, скриншоты образов или вещи, которые хотите стилизовать.',
    upload: 'Загрузить фото',
    finish: 'Создать мои образы',
    home: 'Главная',
    outfits: 'Образы',
    favorites: 'Избранное',
    profile: 'Профиль',
    hello: 'Добрый день',
    readyFor: 'Ваш образ для события',
    editRequest: 'Изменить запрос',
    yourMatch: 'Лучшее совпадение',
    match: 'совпадение',
    viewOutfit: 'Открыть образ',
    curated: 'Подобрано для вас',
    total: 'Итого',
    save: 'Сохранить',
    saved: 'Сохранено',
    settings: 'Настройки',
    appearance: 'Оформление',
    language: 'Язык',
    city: 'Город',
    sizes: 'Размеры',
    references: 'Мои референсы',
    restart: 'Пройти настройку заново',
    favoritesEmpty: 'Здесь появятся сохранённые образы.',
    demoNotice: 'Это визуальный MVP. Покупки и реальные магазины подключаются на следующем этапе.',
    madeFor: 'Создано под ваш бюджет и параметры',
  },
  en: {
    continue: 'Continue', back: 'Back', skip: 'Skip',
    welcomeEyebrow: 'YOUR PERSONAL STYLIST', welcomeTitle: 'Outfits that feel like you.',
    welcomeText: 'NOVERA builds a complete look around your city, occasion, budget, and personal style.',
    start: 'Get started', languageTitle: 'Choose language', languageText: 'You can change it later in Settings.',
    authTitle: 'Welcome to NOVERA', signup: 'Sign up', login: 'Log in', name: 'Name', email: 'Email', password: 'Password',
    authHint: 'Demo version: data is stored only on this device.', genderTitle: 'Who are we styling?',
    genderText: 'This shapes recommendations without limiting your style.', women: 'Women', men: 'Men', unisex: 'Unisex',
    cityTitle: 'Where are you?', cityText: 'We will prioritize items available in your city or with suitable delivery.', cityPlaceholder: 'Enter city',
    appearanceTitle: 'Choose your appearance', appearanceText: 'You can always switch themes in your profile.', lightTheme: 'Light Theme', darkTheme: 'Dark Theme',
    occasionTitle: 'Where are you going?', occasionText: 'Choose an occasion so the stylist can match the dress code and mood.',
    date: 'Date', party: 'Party', birthday: 'Birthday', restaurant: 'Restaurant', concert: 'Concert', wedding: 'Wedding', work: 'Work', travel: 'Travel', other: 'Other',
    measurementsTitle: 'Your measurements', measurementsText: 'This keeps recommendations realistic and size-aware.', budget: 'Outfit budget', clothingSize: 'Clothing size', shoeSize: 'Shoe size', height: 'Height, cm',
    prefsTitle: 'Your preferences', prefsText: 'Choose favorite shades and tell us what you never wear.', favoriteColors: 'Favorite colors', avoid: 'I do not wear / like', avoidPlaceholder: 'For example: mini, heels, neon, leather…',
    uploadTitle: 'Add references', uploadText: 'Upload your photos, outfit screenshots, or an item you want to style.', upload: 'Upload photos', finish: 'Create my outfits',
    home: 'Home', outfits: 'Outfits', favorites: 'Favorites', profile: 'Profile', hello: 'Good afternoon', readyFor: 'Your outfit for', editRequest: 'Edit request', yourMatch: 'Best match', match: 'match', viewOutfit: 'View outfit', curated: 'Curated for you', total: 'Total', save: 'Save', saved: 'Saved', settings: 'Settings', appearance: 'Appearance', language: 'Language', city: 'City', sizes: 'Sizes', references: 'My references', restart: 'Restart onboarding', favoritesEmpty: 'Saved outfits will appear here.', demoNotice: 'This is a visual MVP. Real stores and checkout come in the next phase.', madeFor: 'Built around your budget and measurements',
  },
};

const occasions = [
  ['date', 'heart-outline'], ['party', 'sparkles-outline'], ['birthday', 'gift-outline'],
  ['restaurant', 'restaurant-outline'], ['concert', 'musical-notes-outline'], ['wedding', 'diamond-outline'],
  ['work', 'briefcase-outline'], ['travel', 'airplane-outline'], ['other', 'add-outline'],
];

const colors = [
  { name: 'Чёрный', hex: '#171719' }, { name: 'Белый', hex: '#F8F5EF' },
  { name: 'Кремовый', hex: '#EADBC8' }, { name: 'Персиковый', hex: '#F1B39F' },
  { name: 'Розовый', hex: '#E8A9B8' }, { name: 'Красный', hex: '#9F2435' },
  { name: 'Синий', hex: '#435B82' }, { name: 'Зелёный', hex: '#566D5D' },
  { name: 'Коричневый', hex: '#775340' }, { name: 'Золотой', hex: '#B78C46' },
];

const outfitData = [
  {
    id: 'sunset-silk',
    titleRu: 'Sunset Silk', titleEn: 'Sunset Silk', match: 96,
    occasionRu: 'Ресторан · Москва', occasionEn: 'Restaurant · Moscow',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1200&q=85',
    total: '38 490 ₽',
    noteRu: 'Мягкий персиковый, чистый силуэт и золотые детали.',
    noteEn: 'Soft peach, a clean silhouette, and gold details.',
    items: [
      { nameRu: 'Шёлковое платье', nameEn: 'Silk dress', price: '18 900 ₽', image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Кожаные мюли', nameEn: 'Leather mules', price: '8 990 ₽', image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Мини-сумка', nameEn: 'Mini bag', price: '7 400 ₽', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Серьги', nameEn: 'Earrings', price: '3 200 ₽', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=600&q=80' },
    ],
  },
  {
    id: 'noir-line',
    titleRu: 'Noir Line', titleEn: 'Noir Line', match: 91,
    occasionRu: 'Вечеринка · Москва', occasionEn: 'Party · Moscow',
    image: 'https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=1200&q=85',
    total: '44 800 ₽',
    noteRu: 'Чёрная база, архитектурный жакет и выразительное золото.',
    noteEn: 'A black foundation, architectural blazer, and statement gold.',
    items: [
      { nameRu: 'Жакет', nameEn: 'Blazer', price: '16 500 ₽', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Топ', nameEn: 'Top', price: '5 900 ₽', image: 'https://images.unsplash.com/photo-1564257577054-692621ddc3e1?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Брюки', nameEn: 'Trousers', price: '10 900 ₽', image: 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Клатч', nameEn: 'Clutch', price: '11 500 ₽', image: 'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=600&q=80' },
    ],
  },
  {
    id: 'soft-structure',
    titleRu: 'Soft Structure', titleEn: 'Soft Structure', match: 89,
    occasionRu: 'Работа · Санкт-Петербург', occasionEn: 'Work · Saint Petersburg',
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=85',
    total: '31 200 ₽',
    noteRu: 'Спокойная палитра, собранный силуэт и удобная обувь.',
    noteEn: 'A calm palette, polished silhouette, and comfortable footwear.',
    items: [
      { nameRu: 'Тренч', nameEn: 'Trench coat', price: '13 900 ₽', image: 'https://images.unsplash.com/photo-1591900947067-851789555ef3?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Трикотаж', nameEn: 'Knit top', price: '5 400 ₽', image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Лоферы', nameEn: 'Loafers', price: '7 900 ₽', image: 'https://images.unsplash.com/photo-1560343090-f0409e92791a?auto=format&fit=crop&w=600&q=80' },
      { nameRu: 'Сумка', nameEn: 'Bag', price: '4 000 ₽', image: 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=600&q=80' },
    ],
  },
];

function AppLogo({ theme, compact = false }) {
  const t = palette[theme];
  return (
    <View style={[styles.logoWrap, compact && styles.logoWrapCompact, { borderColor: t.gold }]}> 
      <Text style={[styles.logoN, compact && styles.logoNCompact, { color: t.text }]}>N</Text>
      <Text style={[styles.logoE, compact && styles.logoECompact, { color: t.gold }]}>E</Text>
      <View style={[styles.logoLine, { backgroundColor: t.gold }]} />
    </View>
  );
}

function PrimaryButton({ label, onPress, theme, icon, disabled }) {
  const t = palette[theme];
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.primaryButton,
        { backgroundColor: disabled ? t.border : t.text, opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <Text style={[styles.primaryButtonText, { color: theme === 'dark' ? '#111' : '#FFF' }]}>{label}</Text>
      {icon ? <Ionicons name={icon} size={19} color={theme === 'dark' ? '#111' : '#FFF'} /> : null}
    </Pressable>
  );
}

function GhostButton({ label, onPress, theme, icon }) {
  const t = palette[theme];
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.ghostButton, { borderColor: t.border, opacity: pressed ? 0.7 : 1 }]}> 
      {icon ? <Ionicons name={icon} size={18} color={t.text} /> : null}
      <Text style={[styles.ghostButtonText, { color: t.text }]}>{label}</Text>
    </Pressable>
  );
}

function StepHeader({ title, text, theme, step, onBack, language }) {
  const t = palette[theme];
  const c = copy[language];
  return (
    <View>
      <View style={styles.stepTopRow}>
        {step > 0 ? (
          <Pressable onPress={onBack} style={[styles.iconButton, { backgroundColor: t.surface, borderColor: t.border }]}> 
            <Ionicons name="arrow-back" size={20} color={t.text} />
          </Pressable>
        ) : <View style={styles.iconButtonPlaceholder} />}
        <View style={styles.progressTrack}>
          {Array.from({ length: 10 }).map((_, i) => (
            <View key={i} style={[styles.progressDot, { backgroundColor: i <= step ? t.gold : t.border, flex: i === step ? 2.5 : 1 }]} />
          ))}
        </View>
        <Text style={[styles.stepCount, { color: t.muted }]}>{step + 1}/10</Text>
      </View>
      <Text style={[styles.screenTitle, { color: t.text }]}>{title}</Text>
      <Text style={[styles.screenText, { color: t.muted }]}>{text}</Text>
    </View>
  );
}

function ChoiceCard({ label, subtitle, icon, selected, onPress, theme }) {
  const t = palette[theme];
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.choiceCard,
        {
          backgroundColor: selected ? t.surfaceAlt : t.surface,
          borderColor: selected ? t.gold : t.border,
          opacity: pressed ? 0.82 : 1,
        },
      ]}
    >
      <View style={[styles.choiceIcon, { backgroundColor: selected ? t.gold : t.surfaceAlt }]}> 
        <Ionicons name={icon} size={22} color={selected ? (theme === 'dark' ? '#111' : '#FFF') : t.text} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.choiceLabel, { color: t.text }]}>{label}</Text>
        {subtitle ? <Text style={[styles.choiceSubtitle, { color: t.muted }]}>{subtitle}</Text> : null}
      </View>
      <Ionicons name={selected ? 'checkmark-circle' : 'ellipse-outline'} size={23} color={selected ? t.gold : t.border} />
    </Pressable>
  );
}

function Field({ label, value, onChangeText, placeholder, theme, keyboardType, secureTextEntry, icon }) {
  const t = palette[theme];
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={[styles.fieldLabel, { color: t.muted }]}>{label}</Text>
      <View style={[styles.fieldWrap, { backgroundColor: t.surface, borderColor: t.border }]}> 
        {icon ? <Ionicons name={icon} size={19} color={t.gold} /> : null}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={t.muted}
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          style={[styles.field, { color: t.text }]}
        />
      </View>
    </View>
  );
}

function WelcomeScreen({ theme, language, onStart }) {
  const t = palette[theme];
  const c = copy[language];
  return (
    <View style={{ flex: 1, backgroundColor: '#0B0B0C' }}>
      <ImageBackground
        source={{ uri: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1400&q=90' }}
        style={styles.welcomeImage}
        imageStyle={{ opacity: 0.72 }}
      >
        <LinearGradient colors={['rgba(0,0,0,0.04)', 'rgba(0,0,0,0.34)', 'rgba(0,0,0,0.94)']} style={styles.welcomeGradient}>
          <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.welcomeTop}>
              <AppLogo theme="dark" />
              <Text style={styles.brandWord}>NOVERA STYLE</Text>
            </View>
            <View style={styles.welcomeContent}>
              <Text style={styles.welcomeEyebrow}>{c.welcomeEyebrow}</Text>
              <Text style={styles.welcomeTitle}>{c.welcomeTitle}</Text>
              <Text style={styles.welcomeText}>{c.welcomeText}</Text>
              <Pressable onPress={onStart} style={({ pressed }) => [styles.welcomeButton, { opacity: pressed ? 0.85 : 1 }]}> 
                <Text style={styles.welcomeButtonText}>{c.start}</Text>
                <Ionicons name="arrow-forward" size={20} color="#17120D" />
              </Pressable>
            </View>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

function Onboarding({ theme, setTheme, language, setLanguage, onComplete }) {
  const [step, setStep] = useState(0);
  const [authMode, setAuthMode] = useState('signup');
  const [form, setForm] = useState({
    name: '', email: '', password: '', gender: 'women', city: 'Москва', occasion: 'restaurant',
    budget: '40 000 ₽', clothingSize: 'S / 42', shoeSize: '39', height: '170',
    favoriteColors: ['#171719', '#EADBC8', '#F1B39F'], avoid: '', images: [],
  });
  const t = palette[theme];
  const c = copy[language];

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
  const next = () => setStep(prev => Math.min(9, prev + 1));
  const back = () => setStep(prev => Math.max(0, prev - 1));

  const pickImages = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(language === 'ru' ? 'Нужен доступ к фото' : 'Photo access needed');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'], allowsMultipleSelection: true, quality: 0.8, selectionLimit: 6,
    });
    if (!result.canceled) update('images', [...form.images, ...result.assets.map(a => a.uri)].slice(0, 6));
  };

  const complete = async () => {
    await AsyncStorage.setItem('novera-profile', JSON.stringify(form));
    await AsyncStorage.setItem('novera-onboarded', 'true');
    onComplete(form);
  };

  const renderStep = () => {
    if (step === 0) return (
      <>
        <StepHeader title={c.languageTitle} text={c.languageText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.sectionGap}>
          <ChoiceCard label="Русский" subtitle="Основной язык первой версии" icon="language-outline" selected={language === 'ru'} onPress={() => setLanguage('ru')} theme={theme} />
          <ChoiceCard label="English" subtitle="English interface" icon="globe-outline" selected={language === 'en'} onPress={() => setLanguage('en')} theme={theme} />
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 1) return (
      <>
        <StepHeader title={c.authTitle} text={c.authHint} theme={theme} step={step} onBack={back} language={language} />
        <View style={[styles.segment, { backgroundColor: t.surfaceAlt }]}> 
          {['signup', 'login'].map(mode => (
            <Pressable key={mode} onPress={() => setAuthMode(mode)} style={[styles.segmentItem, authMode === mode && { backgroundColor: t.surface }]}> 
              <Text style={[styles.segmentText, { color: authMode === mode ? t.text : t.muted }]}>{mode === 'signup' ? c.signup : c.login}</Text>
            </Pressable>
          ))}
        </View>
        {authMode === 'signup' && <Field label={c.name} value={form.name} onChangeText={v => update('name', v)} placeholder="Eva" theme={theme} icon="person-outline" />}
        <Field label={c.email} value={form.email} onChangeText={v => update('email', v)} placeholder="you@example.com" theme={theme} keyboardType="email-address" icon="mail-outline" />
        <Field label={c.password} value={form.password} onChangeText={v => update('password', v)} placeholder="••••••••" theme={theme} secureTextEntry icon="lock-closed-outline" />
        <View style={styles.bottomAction}><PrimaryButton label={authMode === 'signup' ? c.signup : c.login} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 2) return (
      <>
        <StepHeader title={c.genderTitle} text={c.genderText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.sectionGap}>
          <ChoiceCard label={c.women} icon="woman-outline" selected={form.gender === 'women'} onPress={() => update('gender', 'women')} theme={theme} />
          <ChoiceCard label={c.men} icon="man-outline" selected={form.gender === 'men'} onPress={() => update('gender', 'men')} theme={theme} />
          <ChoiceCard label={c.unisex} icon="people-outline" selected={form.gender === 'unisex'} onPress={() => update('gender', 'unisex')} theme={theme} />
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 3) return (
      <>
        <StepHeader title={c.cityTitle} text={c.cityText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.sectionGap}>
          <Field label={c.city} value={form.city} onChangeText={v => update('city', v)} placeholder={c.cityPlaceholder} theme={theme} icon="location-outline" />
          <View style={styles.chipRow}>
            {['Москва', 'Санкт-Петербург', 'Dubai', 'Berlin'].map(city => (
              <Pressable key={city} onPress={() => update('city', city)} style={[styles.chip, { borderColor: form.city === city ? t.gold : t.border, backgroundColor: form.city === city ? t.surfaceAlt : t.surface }]}> 
                <Text style={[styles.chipText, { color: t.text }]}>{city}</Text>
              </Pressable>
            ))}
          </View>
          <View style={[styles.cityVisual, { backgroundColor: t.surfaceAlt }]}> 
            <Ionicons name="location" size={34} color={t.gold} />
            <Text style={[styles.cityVisualTitle, { color: t.text }]}>{form.city || c.cityPlaceholder}</Text>
            <Text style={[styles.cityVisualText, { color: t.muted }]}>{language === 'ru' ? 'Локальные магазины + доставка' : 'Local stores + delivery'}</Text>
          </View>
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 4) return (
      <>
        <StepHeader title={c.appearanceTitle} text={c.appearanceText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.themeGrid}>
          <Pressable onPress={() => setTheme('light')} style={[styles.themePreview, { backgroundColor: '#FFF9F5', borderColor: theme === 'light' ? t.gold : t.border }]}> 
            <View style={styles.themeMockHeader}><View style={[styles.themeMockLogo, { borderColor: '#B88A43' }]} /><View style={styles.themeMockLines}><View style={[styles.mockLine, { backgroundColor: '#211B19', width: '70%' }]} /><View style={[styles.mockLine, { backgroundColor: '#EBDDD5', width: '46%' }]} /></View></View>
            <View style={[styles.themeMockCard, { backgroundColor: '#FFFFFF' }]}><View style={[styles.themeMockImage, { backgroundColor: '#F1B9A5' }]} /><View style={[styles.mockLine, { backgroundColor: '#211B19', width: '72%' }]} /><View style={[styles.mockLine, { backgroundColor: '#EBDDD5', width: '50%' }]} /></View>
            <Text style={[styles.themePreviewTitle, { color: '#211B19' }]}>{c.lightTheme}</Text>
            {theme === 'light' && <Ionicons name="checkmark-circle" size={25} color="#B88A43" style={styles.themeCheck} />}
          </Pressable>
          <Pressable onPress={() => setTheme('dark')} style={[styles.themePreview, { backgroundColor: '#101011', borderColor: theme === 'dark' ? t.gold : '#363238' }]}> 
            <View style={styles.themeMockHeader}><View style={[styles.themeMockLogo, { borderColor: '#D5B06B' }]} /><View style={styles.themeMockLines}><View style={[styles.mockLine, { backgroundColor: '#F7F2EA', width: '70%' }]} /><View style={[styles.mockLine, { backgroundColor: '#363238', width: '46%' }]} /></View></View>
            <View style={[styles.themeMockCard, { backgroundColor: '#18181A' }]}><View style={[styles.themeMockImage, { backgroundColor: '#8A5C51' }]} /><View style={[styles.mockLine, { backgroundColor: '#F7F2EA', width: '72%' }]} /><View style={[styles.mockLine, { backgroundColor: '#363238', width: '50%' }]} /></View>
            <Text style={[styles.themePreviewTitle, { color: '#F7F2EA' }]}>{c.darkTheme}</Text>
            {theme === 'dark' && <Ionicons name="checkmark-circle" size={25} color="#D5B06B" style={styles.themeCheck} />}
          </Pressable>
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 5) return (
      <>
        <StepHeader title={c.occasionTitle} text={c.occasionText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.occasionGrid}>
          {occasions.map(([key, icon]) => (
            <Pressable key={key} onPress={() => update('occasion', key)} style={[styles.occasionCard, { backgroundColor: form.occasion === key ? t.surfaceAlt : t.surface, borderColor: form.occasion === key ? t.gold : t.border }]}> 
              <Ionicons name={icon} size={25} color={form.occasion === key ? t.gold : t.text} />
              <Text style={[styles.occasionLabel, { color: t.text }]}>{c[key]}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 6) return (
      <>
        <StepHeader title={c.measurementsTitle} text={c.measurementsText} theme={theme} step={step} onBack={back} language={language} />
        <View style={styles.sectionGap}>
          <Field label={c.budget} value={form.budget} onChangeText={v => update('budget', v)} placeholder="40 000 ₽" theme={theme} keyboardType="numeric" icon="wallet-outline" />
          <View style={styles.twoColumns}>
            <View style={{ flex: 1 }}><Field label={c.clothingSize} value={form.clothingSize} onChangeText={v => update('clothingSize', v)} placeholder="S / 42" theme={theme} icon="shirt-outline" /></View>
            <View style={{ width: 12 }} />
            <View style={{ flex: 1 }}><Field label={c.shoeSize} value={form.shoeSize} onChangeText={v => update('shoeSize', v)} placeholder="39" theme={theme} keyboardType="numeric" icon="footsteps-outline" /></View>
          </View>
          <Field label={c.height} value={form.height} onChangeText={v => update('height', v)} placeholder="170" theme={theme} keyboardType="numeric" icon="resize-outline" />
        </View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 7) return (
      <>
        <StepHeader title={c.prefsTitle} text={c.prefsText} theme={theme} step={step} onBack={back} language={language} />
        <Text style={[styles.fieldLabel, { color: t.muted, marginTop: 26 }]}>{c.favoriteColors}</Text>
        <View style={styles.colorGrid}>
          {colors.map(color => {
            const selected = form.favoriteColors.includes(color.hex);
            return (
              <Pressable key={color.hex} onPress={() => update('favoriteColors', selected ? form.favoriteColors.filter(x => x !== color.hex) : [...form.favoriteColors, color.hex])} style={[styles.colorItem, { borderColor: selected ? t.gold : 'transparent' }]}> 
                <View style={[styles.colorCircle, { backgroundColor: color.hex, borderColor: color.hex === '#F8F5EF' ? t.border : color.hex }]}>{selected && <Ionicons name="checkmark" size={18} color={['#171719', '#9F2435', '#435B82', '#566D5D', '#775340'].includes(color.hex) ? '#FFF' : '#171719'} />}</View>
                <Text numberOfLines={1} style={[styles.colorName, { color: t.muted }]}>{language === 'ru' ? color.name : color.name}</Text>
              </Pressable>
            );
          })}
        </View>
        <View style={{ marginTop: 18 }}><Field label={c.avoid} value={form.avoid} onChangeText={v => update('avoid', v)} placeholder={c.avoidPlaceholder} theme={theme} icon="ban-outline" /></View>
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    if (step === 8) return (
      <>
        <StepHeader title={c.uploadTitle} text={c.uploadText} theme={theme} step={step} onBack={back} language={language} />
        <Pressable onPress={pickImages} style={[styles.uploadBox, { backgroundColor: t.surface, borderColor: t.border }]}> 
          <View style={[styles.uploadIcon, { backgroundColor: t.surfaceAlt }]}><Ionicons name="images-outline" size={31} color={t.gold} /></View>
          <Text style={[styles.uploadTitle, { color: t.text }]}>{c.upload}</Text>
          <Text style={[styles.uploadMeta, { color: t.muted }]}>JPG, PNG · {language === 'ru' ? 'до 6 фото' : 'up to 6 photos'}</Text>
        </Pressable>
        {form.images.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 18 }} contentContainerStyle={{ gap: 12 }}>
            {form.images.map((uri, index) => (
              <View key={`${uri}-${index}`}>
                <Image source={{ uri }} style={styles.referenceImage} />
                <Pressable onPress={() => update('images', form.images.filter((_, i) => i !== index))} style={styles.removeImage}><Ionicons name="close" size={17} color="#FFF" /></Pressable>
              </View>
            ))}
          </ScrollView>
        )}
        <View style={styles.bottomAction}><PrimaryButton label={c.continue} onPress={next} theme={theme} icon="arrow-forward" /></View>
      </>
    );
    return (
      <>
        <StepHeader title={language === 'ru' ? 'Всё готово' : 'You are all set'} text={language === 'ru' ? 'Мы собрали ваш стиль-профиль. Теперь NOVERA может создавать образы персонально для вас.' : 'Your style profile is ready. NOVERA can now build personalized outfits for you.'} theme={theme} step={step} onBack={back} language={language} />
        <View style={[styles.summaryCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
          <View style={styles.summaryHeader}><AppLogo theme={theme} compact /><View><Text style={[styles.summaryName, { color: t.text }]}>{form.name || 'NOVERA USER'}</Text><Text style={[styles.summarySub, { color: t.muted }]}>{form.city} · {c[form.occasion]}</Text></View></View>
          <View style={[styles.summaryDivider, { backgroundColor: t.border }]} />
          <View style={styles.summaryRows}>
            <SummaryRow icon="wallet-outline" label={c.budget} value={form.budget} theme={theme} />
            <SummaryRow icon="shirt-outline" label={c.sizes} value={`${form.clothingSize} · ${form.shoeSize}`} theme={theme} />
            <SummaryRow icon="resize-outline" label={c.height} value={`${form.height} cm`} theme={theme} />
            <SummaryRow icon="images-outline" label={c.references} value={`${form.images.length}`} theme={theme} />
          </View>
          <View style={styles.palettePreview}>{form.favoriteColors.map(hex => <View key={hex} style={[styles.paletteDot, { backgroundColor: hex, borderColor: t.border }]} />)}</View>
        </View>
        <Text style={[styles.demoNote, { color: t.muted }]}>{c.demoNotice}</Text>
        <View style={styles.bottomAction}><PrimaryButton label={c.finish} onPress={complete} theme={theme} icon="sparkles-outline" /></View>
      </>
    );
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: t.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.onboardingScroll}>
          {renderStep()}
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

function SummaryRow({ icon, label, value, theme }) {
  const t = palette[theme];
  return <View style={styles.summaryRow}><Ionicons name={icon} size={18} color={t.gold} /><Text style={[styles.summaryRowLabel, { color: t.muted }]}>{label}</Text><Text style={[styles.summaryRowValue, { color: t.text }]}>{value}</Text></View>;
}

function MainApp({ theme, setTheme, language, setLanguage, profile, onRestart }) {
  const [tab, setTab] = useState('home');
  const [favoriteIds, setFavoriteIds] = useState(['sunset-silk']);
  const t = palette[theme];
  const c = copy[language];

  const toggleFavorite = id => setFavoriteIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const occasionLabel = c[profile.occasion] || c.restaurant;

  const content = tab === 'home'
    ? <HomeScreen theme={theme} language={language} profile={profile} occasionLabel={occasionLabel} setTab={setTab} favoriteIds={favoriteIds} toggleFavorite={toggleFavorite} />
    : tab === 'outfits'
      ? <OutfitsScreen theme={theme} language={language} favoriteIds={favoriteIds} toggleFavorite={toggleFavorite} />
      : tab === 'favorites'
        ? <FavoritesScreen theme={theme} language={language} favoriteIds={favoriteIds} toggleFavorite={toggleFavorite} />
        : <ProfileScreen theme={theme} setTheme={setTheme} language={language} setLanguage={setLanguage} profile={profile} onRestart={onRestart} />;

  return (
    <View style={{ flex: 1, backgroundColor: t.background }}>
      <StatusBar barStyle={theme === 'dark' ? 'light-content' : 'dark-content'} />
      <SafeAreaView style={{ flex: 1 }}>
        {content}
      </SafeAreaView>
      <View style={[styles.bottomNav, { backgroundColor: t.surface, borderTopColor: t.border }]}> 
        {[
          ['home', 'home-outline', 'home'], ['outfits', 'sparkles-outline', 'outfits'],
          ['favorites', 'heart-outline', 'favorites'], ['profile', 'person-outline', 'profile'],
        ].map(([key, icon, label]) => (
          <Pressable key={key} onPress={() => setTab(key)} style={styles.navItem}>
            <View style={[styles.navIconWrap, tab === key && { backgroundColor: t.surfaceAlt }]}><Ionicons name={tab === key ? icon.replace('-outline', '') : icon} size={22} color={tab === key ? t.gold : t.muted} /></View>
            <Text style={[styles.navLabel, { color: tab === key ? t.gold : t.muted }]}>{c[label]}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

function AppHeader({ theme, title, subtitle, rightIcon, onRight }) {
  const t = palette[theme];
  return (
    <View style={styles.appHeader}>
      <View style={{ flex: 1 }}>
        {subtitle ? <Text style={[styles.headerSubtitle, { color: t.muted }]}>{subtitle}</Text> : null}
        <Text style={[styles.headerTitle, { color: t.text }]}>{title}</Text>
      </View>
      {rightIcon ? <Pressable onPress={onRight} style={[styles.iconButton, { backgroundColor: t.surface, borderColor: t.border }]}><Ionicons name={rightIcon} size={20} color={t.text} /></Pressable> : <AppLogo theme={theme} compact />}
    </View>
  );
}

function HomeScreen({ theme, language, profile, occasionLabel, setTab, favoriteIds, toggleFavorite }) {
  const t = palette[theme];
  const c = copy[language];
  const hero = outfitData[0];
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.mainScroll}>
      <AppHeader theme={theme} subtitle={c.hello} title={profile.name || 'Eva'} rightIcon="notifications-outline" />
      <View style={[styles.requestCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
        <View style={[styles.requestIcon, { backgroundColor: t.surfaceAlt }]}><Ionicons name="restaurant-outline" size={22} color={t.gold} /></View>
        <View style={{ flex: 1 }}><Text style={[styles.requestEyebrow, { color: t.muted }]}>{c.readyFor}</Text><Text style={[styles.requestTitle, { color: t.text }]}>{occasionLabel} · {profile.city}</Text></View>
        <Pressable><Text style={[styles.editText, { color: t.gold }]}>{c.editRequest}</Text></Pressable>
      </View>
      <Text style={[styles.sectionTitle, { color: t.text }]}>{c.yourMatch}</Text>
      <View style={[styles.heroCard, { backgroundColor: t.surface }]}> 
        <ImageBackground source={{ uri: hero.image }} style={styles.heroImage} imageStyle={styles.heroImageStyle}>
          <LinearGradient colors={['transparent', 'rgba(0,0,0,0.78)']} style={styles.heroOverlay}>
            <View style={styles.matchPill}><Ionicons name="sparkles" size={14} color="#17120D" /><Text style={styles.matchPillText}>{hero.match}% {c.match}</Text></View>
            <View style={styles.heroBottom}>
              <View style={{ flex: 1 }}><Text style={styles.heroTitle}>{language === 'ru' ? hero.titleRu : hero.titleEn}</Text><Text style={styles.heroNote}>{language === 'ru' ? hero.noteRu : hero.noteEn}</Text></View>
              <Pressable onPress={() => toggleFavorite(hero.id)} style={styles.heroHeart}><Ionicons name={favoriteIds.includes(hero.id) ? 'heart' : 'heart-outline'} size={22} color="#FFF" /></Pressable>
            </View>
          </LinearGradient>
        </ImageBackground>
        <View style={styles.heroFooter}><View><Text style={[styles.heroMeta, { color: t.muted }]}>{language === 'ru' ? hero.occasionRu : hero.occasionEn}</Text><Text style={[styles.heroPrice, { color: t.text }]}>{hero.total}</Text></View><Pressable onPress={() => setTab('outfits')} style={[styles.miniButton, { backgroundColor: t.text }]}><Text style={[styles.miniButtonText, { color: theme === 'dark' ? '#111' : '#FFF' }]}>{c.viewOutfit}</Text><Ionicons name="arrow-forward" size={16} color={theme === 'dark' ? '#111' : '#FFF'} /></Pressable></View>
      </View>
      <View style={styles.titleRow}><Text style={[styles.sectionTitle, { color: t.text, marginBottom: 0 }]}>{c.curated}</Text><Pressable onPress={() => setTab('outfits')}><Text style={[styles.editText, { color: t.gold }]}>{language === 'ru' ? 'Все образы' : 'See all'}</Text></Pressable></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 14, paddingRight: 20 }}>
        {outfitData.slice(1).map(outfit => <MiniOutfit key={outfit.id} outfit={outfit} theme={theme} language={language} />)}
      </ScrollView>
      <View style={[styles.infoBanner, { backgroundColor: t.surfaceAlt }]}><Ionicons name="information-circle-outline" size={22} color={t.gold} /><Text style={[styles.infoBannerText, { color: t.muted }]}>{c.madeFor}: {profile.budget}, {profile.clothingSize}, {profile.shoeSize}</Text></View>
    </ScrollView>
  );
}

function MiniOutfit({ outfit, theme, language }) {
  const t = palette[theme];
  return (
    <View style={[styles.miniOutfitCard, { backgroundColor: t.surface, borderColor: t.border }]}>
      <Image source={{ uri: outfit.image }} style={styles.miniOutfitImage} />
      <Text style={[styles.miniOutfitTitle, { color: t.text }]}>{language === 'ru' ? outfit.titleRu : outfit.titleEn}</Text>
      <View style={styles.miniOutfitRow}><Text style={[styles.miniOutfitMeta, { color: t.muted }]}>{outfit.match}%</Text><Text style={[styles.miniOutfitPrice, { color: t.text }]}>{outfit.total}</Text></View>
    </View>
  );
}

function OutfitsScreen({ theme, language, favoriteIds, toggleFavorite }) {
  const t = palette[theme];
  const c = copy[language];
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.mainScroll}>
      <AppHeader theme={theme} title={c.outfits} subtitle={language === 'ru' ? 'Персональная подборка' : 'Personal edit'} rightIcon="options-outline" />
      {outfitData.map(outfit => <OutfitCard key={outfit.id} outfit={outfit} theme={theme} language={language} favorite={favoriteIds.includes(outfit.id)} onFavorite={() => toggleFavorite(outfit.id)} />)}
    </ScrollView>
  );
}

function OutfitCard({ outfit, theme, language, favorite, onFavorite }) {
  const t = palette[theme];
  const c = copy[language];
  return (
    <View style={[styles.outfitCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
      <ImageBackground source={{ uri: outfit.image }} style={styles.outfitHero} imageStyle={styles.outfitHeroImage}>
        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.78)']} style={styles.outfitHeroGradient}>
          <View style={styles.outfitTopRow}><View style={styles.matchPill}><Text style={styles.matchPillText}>{outfit.match}% {c.match}</Text></View><Pressable onPress={onFavorite} style={styles.heroHeart}><Ionicons name={favorite ? 'heart' : 'heart-outline'} size={22} color="#FFF" /></Pressable></View>
          <View><Text style={styles.outfitHeroTitle}>{language === 'ru' ? outfit.titleRu : outfit.titleEn}</Text><Text style={styles.outfitHeroNote}>{language === 'ru' ? outfit.noteRu : outfit.noteEn}</Text></View>
        </LinearGradient>
      </ImageBackground>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.itemStrip}>
        {outfit.items.map((item, idx) => (
          <View key={`${outfit.id}-${idx}`} style={[styles.itemCard, { backgroundColor: t.surfaceAlt }]}> 
            <Image source={{ uri: item.image }} style={styles.itemImage} />
            <Text numberOfLines={1} style={[styles.itemName, { color: t.text }]}>{language === 'ru' ? item.nameRu : item.nameEn}</Text>
            <Text style={[styles.itemPrice, { color: t.muted }]}>{item.price}</Text>
          </View>
        ))}
      </ScrollView>
      <View style={[styles.totalRow, { borderTopColor: t.border }]}><View><Text style={[styles.totalLabel, { color: t.muted }]}>{c.total}</Text><Text style={[styles.totalValue, { color: t.text }]}>{outfit.total}</Text></View><Pressable onPress={onFavorite} style={[styles.saveButton, { borderColor: favorite ? t.gold : t.border, backgroundColor: favorite ? t.surfaceAlt : t.surface }]}><Ionicons name={favorite ? 'heart' : 'heart-outline'} size={18} color={favorite ? t.gold : t.text} /><Text style={[styles.saveButtonText, { color: favorite ? t.gold : t.text }]}>{favorite ? c.saved : c.save}</Text></Pressable></View>
    </View>
  );
}

function FavoritesScreen({ theme, language, favoriteIds, toggleFavorite }) {
  const t = palette[theme];
  const c = copy[language];
  const saved = outfitData.filter(x => favoriteIds.includes(x.id));
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.mainScroll}>
      <AppHeader theme={theme} title={c.favorites} subtitle={`${saved.length} ${language === 'ru' ? 'сохранено' : 'saved'}`} />
      {saved.length === 0 ? (
        <View style={[styles.emptyState, { backgroundColor: t.surface, borderColor: t.border }]}><View style={[styles.emptyIcon, { backgroundColor: t.surfaceAlt }]}><Ionicons name="heart-outline" size={36} color={t.gold} /></View><Text style={[styles.emptyTitle, { color: t.text }]}>{c.favorites}</Text><Text style={[styles.emptyText, { color: t.muted }]}>{c.favoritesEmpty}</Text></View>
      ) : saved.map(outfit => <OutfitCard key={outfit.id} outfit={outfit} theme={theme} language={language} favorite onFavorite={() => toggleFavorite(outfit.id)} />)}
    </ScrollView>
  );
}

function ProfileScreen({ theme, setTheme, language, setLanguage, profile, onRestart }) {
  const t = palette[theme];
  const c = copy[language];
  const initials = (profile.name || 'N').slice(0, 1).toUpperCase();
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.mainScroll}>
      <AppHeader theme={theme} title={c.profile} subtitle="NOVERA STYLE" rightIcon="settings-outline" />
      <View style={[styles.profileCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
        <LinearGradient colors={theme === 'dark' ? ['#443226', '#18181A'] : ['#F7D8CA', '#FFF7F1']} style={styles.profileGradient}>
          <View style={[styles.avatar, { backgroundColor: t.surface, borderColor: t.gold }]}><Text style={[styles.avatarText, { color: t.gold }]}>{initials}</Text></View>
          <Text style={[styles.profileName, { color: t.text }]}>{profile.name || 'NOVERA USER'}</Text>
          <Text style={[styles.profileMeta, { color: t.muted }]}>{profile.city} · {profile.clothingSize} · {profile.shoeSize}</Text>
        </LinearGradient>
      </View>
      <Text style={[styles.sectionTitle, { color: t.text }]}>{c.settings}</Text>
      <View style={[styles.settingsCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
        <View style={styles.settingBlock}>
          <View style={styles.settingTitleRow}><View style={[styles.settingIcon, { backgroundColor: t.surfaceAlt }]}><Ionicons name="contrast-outline" size={20} color={t.gold} /></View><View><Text style={[styles.settingTitle, { color: t.text }]}>{c.appearance}</Text><Text style={[styles.settingSubtitle, { color: t.muted }]}>{theme === 'light' ? c.lightTheme : c.darkTheme}</Text></View></View>
          <View style={[styles.themeSwitch, { backgroundColor: t.surfaceAlt }]}> 
            <Pressable onPress={() => setTheme('light')} style={[styles.themeSwitchItem, theme === 'light' && { backgroundColor: t.surface }]}><Ionicons name="sunny-outline" size={18} color={theme === 'light' ? t.gold : t.muted} /><Text style={[styles.themeSwitchText, { color: theme === 'light' ? t.text : t.muted }]}>{language === 'ru' ? 'Светлая' : 'Light'}</Text></Pressable>
            <Pressable onPress={() => setTheme('dark')} style={[styles.themeSwitchItem, theme === 'dark' && { backgroundColor: t.surface }]}><Ionicons name="moon-outline" size={18} color={theme === 'dark' ? t.gold : t.muted} /><Text style={[styles.themeSwitchText, { color: theme === 'dark' ? t.text : t.muted }]}>{language === 'ru' ? 'Тёмная' : 'Dark'}</Text></Pressable>
          </View>
        </View>
        <View style={[styles.settingDivider, { backgroundColor: t.border }]} />
        <View style={styles.settingBlock}>
          <View style={styles.settingTitleRow}><View style={[styles.settingIcon, { backgroundColor: t.surfaceAlt }]}><Ionicons name="language-outline" size={20} color={t.gold} /></View><View><Text style={[styles.settingTitle, { color: t.text }]}>{c.language}</Text><Text style={[styles.settingSubtitle, { color: t.muted }]}>{language === 'ru' ? 'Русский' : 'English'}</Text></View></View>
          <View style={[styles.themeSwitch, { backgroundColor: t.surfaceAlt }]}> 
            <Pressable onPress={() => setLanguage('ru')} style={[styles.themeSwitchItem, language === 'ru' && { backgroundColor: t.surface }]}><Text style={[styles.themeSwitchText, { color: language === 'ru' ? t.text : t.muted }]}>RU</Text></Pressable>
            <Pressable onPress={() => setLanguage('en')} style={[styles.themeSwitchItem, language === 'en' && { backgroundColor: t.surface }]}><Text style={[styles.themeSwitchText, { color: language === 'en' ? t.text : t.muted }]}>EN</Text></Pressable>
          </View>
        </View>
      </View>
      <View style={[styles.profileInfoCard, { backgroundColor: t.surface, borderColor: t.border }]}> 
        <SummaryRow icon="location-outline" label={c.city} value={profile.city} theme={theme} />
        <SummaryRow icon="wallet-outline" label={c.budget} value={profile.budget} theme={theme} />
        <SummaryRow icon="shirt-outline" label={c.sizes} value={`${profile.clothingSize} · ${profile.shoeSize}`} theme={theme} />
        <SummaryRow icon="resize-outline" label={c.height} value={`${profile.height} cm`} theme={theme} />
      </View>
      <GhostButton label={c.restart} onPress={onRestart} theme={theme} icon="refresh-outline" />
      <Text style={[styles.versionText, { color: t.muted }]}>NOVERA Style · MVP 1.0</Text>
    </ScrollView>
  );
}

export default function App() {
  const [theme, setThemeState] = useState('light');
  const [language, setLanguageState] = useState('ru');
  const [started, setStarted] = useState(false);
  const [onboarded, setOnboarded] = useState(false);
  const [profile, setProfile] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      const savedTheme = await AsyncStorage.getItem('novera-theme');
      const savedLanguage = await AsyncStorage.getItem('novera-language');
      const savedOnboarded = await AsyncStorage.getItem('novera-onboarded');
      const savedProfile = await AsyncStorage.getItem('novera-profile');
      if (savedTheme) setThemeState(savedTheme);
      if (savedLanguage) setLanguageState(savedLanguage);
      if (savedOnboarded === 'true' && savedProfile) {
        setProfile(JSON.parse(savedProfile));
        setOnboarded(true);
        setStarted(true);
      }
      setReady(true);
    })();
  }, []);

  const setTheme = async value => { setThemeState(value); await AsyncStorage.setItem('novera-theme', value); };
  const setLanguage = async value => { setLanguageState(value); await AsyncStorage.setItem('novera-language', value); };
  const complete = data => { setProfile(data); setOnboarded(true); };
  const restart = async () => { await AsyncStorage.removeItem('novera-onboarded'); setOnboarded(false); setStarted(true); };

  if (!ready) return <View style={{ flex: 1, backgroundColor: palette[theme].background }} />;
  if (!started) return <WelcomeScreen theme={theme} language={language} onStart={() => setStarted(true)} />;
  if (!onboarded) return <Onboarding theme={theme} setTheme={setTheme} language={language} setLanguage={setLanguage} onComplete={complete} />;
  return <MainApp theme={theme} setTheme={setTheme} language={language} setLanguage={setLanguage} profile={profile} onRestart={restart} />;
}

const styles = StyleSheet.create({
  welcomeImage: { flex: 1 }, welcomeGradient: { flex: 1 },
  welcomeTop: { paddingHorizontal: 24, paddingTop: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  brandWord: { color: '#FFF', fontSize: 13, letterSpacing: 3.4, fontWeight: '600' },
  welcomeContent: { marginTop: 'auto', paddingHorizontal: 24, paddingBottom: 30 },
  welcomeEyebrow: { color: '#D6B06A', letterSpacing: 2.2, fontSize: 11, fontWeight: '700', marginBottom: 16 },
  welcomeTitle: { color: '#FFF', fontSize: 45, lineHeight: 49, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', maxWidth: 350 },
  welcomeText: { color: 'rgba(255,255,255,0.75)', fontSize: 16, lineHeight: 24, marginTop: 18, maxWidth: 345 },
  welcomeButton: { height: 58, borderRadius: 22, backgroundColor: '#E9C688', marginTop: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  welcomeButtonText: { color: '#17120D', fontSize: 16, fontWeight: '700' },
  logoWrap: { width: 56, height: 56, borderWidth: 1, borderRadius: 20, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  logoWrapCompact: { width: 43, height: 43, borderRadius: 15 },
  logoN: { position: 'absolute', fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', fontSize: 29, left: 10, top: 11 },
  logoNCompact: { fontSize: 22, left: 8, top: 8 },
  logoE: { position: 'absolute', fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', fontSize: 27, right: 9, bottom: 7, fontStyle: 'italic' },
  logoECompact: { fontSize: 20, right: 7, bottom: 5 },
  logoLine: { position: 'absolute', width: 39, height: 1, transform: [{ rotate: '-35deg' }] },
  onboardingScroll: { paddingHorizontal: 22, paddingTop: 10, paddingBottom: 28, minHeight: '100%' },
  stepTopRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 26 },
  iconButton: { width: 43, height: 43, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  iconButtonPlaceholder: { width: 43, height: 43 },
  progressTrack: { flex: 1, height: 4, flexDirection: 'row', gap: 4 },
  progressDot: { height: 4, borderRadius: 99 }, stepCount: { fontSize: 12, fontWeight: '600', minWidth: 30, textAlign: 'right' },
  screenTitle: { fontSize: 34, lineHeight: 39, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' },
  screenText: { fontSize: 15, lineHeight: 22, marginTop: 10, maxWidth: 355 },
  sectionGap: { marginTop: 28, gap: 12 },
  bottomAction: { marginTop: 28 },
  primaryButton: { minHeight: 58, borderRadius: 20, paddingHorizontal: 22, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  primaryButtonText: { fontSize: 16, fontWeight: '700' },
  ghostButton: { minHeight: 54, borderRadius: 18, borderWidth: 1, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  ghostButtonText: { fontSize: 15, fontWeight: '600' },
  choiceCard: { minHeight: 82, padding: 16, borderRadius: 22, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 13 },
  choiceIcon: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  choiceLabel: { fontSize: 16, fontWeight: '700' }, choiceSubtitle: { marginTop: 4, fontSize: 12, lineHeight: 17 },
  segment: { flexDirection: 'row', padding: 5, borderRadius: 17, marginTop: 25, marginBottom: 23 },
  segmentItem: { flex: 1, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, segmentText: { fontSize: 14, fontWeight: '700' },
  fieldLabel: { fontSize: 12, fontWeight: '700', letterSpacing: 0.4, marginBottom: 8 },
  fieldWrap: { height: 56, borderRadius: 18, borderWidth: 1, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 10 },
  field: { flex: 1, fontSize: 16, height: '100%' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  chip: { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 99, borderWidth: 1 }, chipText: { fontSize: 13, fontWeight: '600' },
  cityVisual: { height: 150, borderRadius: 25, marginTop: 8, alignItems: 'center', justifyContent: 'center' },
  cityVisualTitle: { fontSize: 21, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', marginTop: 8 }, cityVisualText: { fontSize: 12, marginTop: 5 },
  themeGrid: { flexDirection: 'row', gap: 12, marginTop: 28 },
  themePreview: { flex: 1, height: 270, borderRadius: 26, borderWidth: 2, padding: 13, overflow: 'hidden' },
  themeMockHeader: { flexDirection: 'row', gap: 8, alignItems: 'center' }, themeMockLogo: { width: 27, height: 27, borderWidth: 1, borderRadius: 9 }, themeMockLines: { flex: 1, gap: 5 },
  mockLine: { height: 5, borderRadius: 20 }, themeMockCard: { marginTop: 18, borderRadius: 16, padding: 8, gap: 7 }, themeMockImage: { height: 108, borderRadius: 12 },
  themePreviewTitle: { marginTop: 18, fontSize: 15, fontWeight: '700' }, themeCheck: { position: 'absolute', right: 12, bottom: 10 },
  occasionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 27 },
  occasionCard: { width: (width - 64) / 3, aspectRatio: 1, borderRadius: 21, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8, gap: 9 },
  occasionLabel: { fontSize: 12, textAlign: 'center', fontWeight: '600' },
  twoColumns: { flexDirection: 'row' },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 15 },
  colorItem: { width: '18%', alignItems: 'center', gap: 5, borderWidth: 1.5, borderRadius: 17, paddingVertical: 8 },
  colorCircle: { width: 37, height: 37, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center' }, colorName: { fontSize: 9, maxWidth: 58 },
  uploadBox: { marginTop: 28, borderWidth: 1.5, borderStyle: 'dashed', borderRadius: 26, height: 220, alignItems: 'center', justifyContent: 'center' },
  uploadIcon: { width: 66, height: 66, borderRadius: 22, alignItems: 'center', justifyContent: 'center' }, uploadTitle: { fontSize: 17, fontWeight: '700', marginTop: 14 }, uploadMeta: { fontSize: 12, marginTop: 6 },
  referenceImage: { width: 112, height: 142, borderRadius: 19 }, removeImage: { position: 'absolute', top: 7, right: 7, width: 25, height: 25, borderRadius: 13, backgroundColor: 'rgba(0,0,0,0.62)', alignItems: 'center', justifyContent: 'center' },
  summaryCard: { borderWidth: 1, borderRadius: 28, padding: 20, marginTop: 28 }, summaryHeader: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  summaryName: { fontSize: 16, fontWeight: '700' }, summarySub: { fontSize: 12, marginTop: 3 }, summaryDivider: { height: 1, marginVertical: 18 }, summaryRows: { gap: 13 },
  summaryRow: { flexDirection: 'row', alignItems: 'center', gap: 9 }, summaryRowLabel: { flex: 1, fontSize: 13 }, summaryRowValue: { fontSize: 13, fontWeight: '700' },
  palettePreview: { flexDirection: 'row', marginTop: 19 }, paletteDot: { width: 31, height: 31, borderRadius: 16, borderWidth: 1, marginRight: -5 }, demoNote: { fontSize: 12, lineHeight: 18, marginTop: 15, textAlign: 'center' },
  mainScroll: { paddingHorizontal: 18, paddingTop: 8, paddingBottom: 110 },
  appHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 22 }, headerSubtitle: { fontSize: 11, letterSpacing: 1.2, textTransform: 'uppercase', fontWeight: '700' }, headerTitle: { fontSize: 31, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', marginTop: 2 },
  bottomNav: { position: 'absolute', left: 0, right: 0, bottom: 0, height: Platform.OS === 'ios' ? 88 : 72, borderTopWidth: 1, flexDirection: 'row', paddingTop: 8, paddingBottom: Platform.OS === 'ios' ? 18 : 7 },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 2 }, navIconWrap: { width: 42, height: 34, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }, navLabel: { fontSize: 9.5, fontWeight: '600' },
  requestCard: { borderWidth: 1, borderRadius: 22, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 25 }, requestIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' }, requestEyebrow: { fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.9, fontWeight: '700' }, requestTitle: { fontSize: 14, fontWeight: '700', marginTop: 3 }, editText: { fontSize: 12, fontWeight: '700' },
  sectionTitle: { fontSize: 22, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', marginBottom: 14 },
  heroCard: { borderRadius: 28, overflow: 'hidden', marginBottom: 27 }, heroImage: { height: 390 }, heroImageStyle: { borderTopLeftRadius: 28, borderTopRightRadius: 28 }, heroOverlay: { flex: 1, padding: 17, justifyContent: 'space-between' },
  matchPill: { alignSelf: 'flex-start', backgroundColor: '#E9C688', paddingHorizontal: 11, height: 30, borderRadius: 99, flexDirection: 'row', alignItems: 'center', gap: 5 }, matchPillText: { color: '#17120D', fontSize: 11, fontWeight: '800' },
  heroBottom: { flexDirection: 'row', alignItems: 'flex-end', gap: 10 }, heroTitle: { color: '#FFF', fontSize: 31, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' }, heroNote: { color: 'rgba(255,255,255,0.75)', fontSize: 12, lineHeight: 18, marginTop: 5, maxWidth: 260 },
  heroHeart: { width: 43, height: 43, borderRadius: 22, backgroundColor: 'rgba(0,0,0,0.28)', alignItems: 'center', justifyContent: 'center' },
  heroFooter: { padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, heroMeta: { fontSize: 11, marginBottom: 3 }, heroPrice: { fontSize: 19, fontWeight: '700' }, miniButton: { height: 42, borderRadius: 15, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 7 }, miniButtonText: { fontSize: 12, fontWeight: '700' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 },
  miniOutfitCard: { width: 174, padding: 10, borderRadius: 22, borderWidth: 1 }, miniOutfitImage: { width: '100%', height: 190, borderRadius: 16 }, miniOutfitTitle: { fontSize: 15, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', marginTop: 10 }, miniOutfitRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 }, miniOutfitMeta: { fontSize: 11 }, miniOutfitPrice: { fontSize: 11, fontWeight: '700' },
  infoBanner: { marginTop: 20, borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 }, infoBannerText: { flex: 1, fontSize: 11, lineHeight: 17 },
  outfitCard: { borderWidth: 1, borderRadius: 28, overflow: 'hidden', marginBottom: 22 }, outfitHero: { height: 330 }, outfitHeroImage: { borderTopLeftRadius: 27, borderTopRightRadius: 27 }, outfitHeroGradient: { flex: 1, padding: 16, justifyContent: 'space-between' }, outfitTopRow: { flexDirection: 'row', justifyContent: 'space-between' }, outfitHeroTitle: { color: '#FFF', fontSize: 29, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' }, outfitHeroNote: { color: 'rgba(255,255,255,0.77)', fontSize: 12, lineHeight: 18, marginTop: 5, maxWidth: 285 },
  itemStrip: { padding: 14, gap: 10 }, itemCard: { width: 118, borderRadius: 17, padding: 8 }, itemImage: { width: '100%', height: 100, borderRadius: 12 }, itemName: { fontSize: 11, fontWeight: '700', marginTop: 7 }, itemPrice: { fontSize: 10, marginTop: 3 },
  totalRow: { borderTopWidth: 1, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, totalLabel: { fontSize: 11 }, totalValue: { fontSize: 20, fontWeight: '700', marginTop: 2 }, saveButton: { height: 43, borderRadius: 15, borderWidth: 1, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 7 }, saveButtonText: { fontSize: 12, fontWeight: '700' },
  emptyState: { borderWidth: 1, borderRadius: 28, padding: 30, alignItems: 'center', marginTop: 35 }, emptyIcon: { width: 76, height: 76, borderRadius: 26, alignItems: 'center', justifyContent: 'center' }, emptyTitle: { fontSize: 21, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif', marginTop: 16 }, emptyText: { fontSize: 13, lineHeight: 19, textAlign: 'center', marginTop: 7 },
  profileCard: { borderWidth: 1, borderRadius: 28, overflow: 'hidden', marginBottom: 27 }, profileGradient: { padding: 25, alignItems: 'center' }, avatar: { width: 78, height: 78, borderRadius: 30, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' }, avatarText: { fontSize: 32, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' }, profileName: { fontSize: 21, fontWeight: '700', marginTop: 13 }, profileMeta: { fontSize: 12, marginTop: 5 },
  settingsCard: { borderWidth: 1, borderRadius: 24, padding: 16, marginBottom: 16 }, settingBlock: { gap: 14 }, settingTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 11 }, settingIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, settingTitle: { fontSize: 14, fontWeight: '700' }, settingSubtitle: { fontSize: 11, marginTop: 2 }, settingDivider: { height: 1, marginVertical: 16 },
  themeSwitch: { flexDirection: 'row', padding: 4, borderRadius: 15 }, themeSwitchItem: { flex: 1, height: 39, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 }, themeSwitchText: { fontSize: 12, fontWeight: '700' },
  profileInfoCard: { borderWidth: 1, borderRadius: 22, padding: 16, gap: 15, marginBottom: 16 }, versionText: { fontSize: 10, textAlign: 'center', marginTop: 18 },
});
