# NOVERA Style — mobile MVP

Luxury minimal fashion styling app built with Expo React Native.

## Included

- Welcome screen and NE monogram
- Russian / English interface (Russian by default)
- Sign up / login demo
- Women / Men / Unisex preferences
- City, theme, occasion, budget, sizes, colors, exclusions
- Photo reference upload through the device library
- Complete outfit recommendations with items, prices, and totals
- Favorites
- Profile and persistent Settings
- Light and dark themes
- Bottom navigation: Home, Outfits, Favorites, Profile

## Run on an iPhone without a Mac

1. Install Node.js LTS on any Windows or Linux computer.
2. Install Expo Go on the iPhone.
3. Open this folder in Terminal and run:

```bash
npm install
npx expo start
```

4. Scan the QR code with the iPhone camera and open it in Expo Go.

The project uses Expo SDK 54 so it can run in Expo Go on a physical device during the current SDK transition.

## Notes

This is a visual, interactive MVP. Authentication, real retailer inventory, recommendation AI, payment, and analytics are represented as product flows and can be connected to a backend later.
